### HSMINWEB Supporting Documentation

This folder provides specific documentation and examples for getting the most out of `hs.httpserver.hsminweb`.

* [Custom Error Functions](functions.md)
* [Lua Template Files](templates.md)
