
--- === hs.sound ===
---
--- Load/play/manipulate sound files


local module = require("hs.libsound")

-- private variables and methods -----------------------------------------

-- Public interface ------------------------------------------------------

-- Return Module Object --------------------------------------------------

return module

