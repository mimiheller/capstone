--- === hs.websocket ===
---
--- Simple websocket client.

local websocket = require("hs.libwebsocket")
return websocket
